﻿namespace CarregarCotacoes
{
    public class SeleniumConfigurations
    {
        public string CaminhoDriverFirefox { get; set; }
        public string UrlPaginaCotacoes { get; set; }
    }
}